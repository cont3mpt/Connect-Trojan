============[Proyecto Msn Tools By .BoLuDo - C�digo fuente]============

Fecha: 27 de Noviembre de 2001
Versi�n del c�digo: 1.0.1

=[Cambios mayores]=

+ Pues esta Versi�n no ha sufrido ningun cambio
+ �Por que?
+ -Pues, por que es mi primera versi�n :S...:P

=[Notas sobre el c�digo fuente]=

  Es necesario extraer el ZIP con todas las rutas (los directorios), pues se
usan rutas relativas; es decir, no importa donde lo pongas pero que tenga todos
los subdirectorios.

  Algunas partes que se refieren a directorios espec�ficos deben ser cambiadas.
Por si alguien tiene curiosidad: no lo ten�a en CD, tengo un segundo disco duro
y ah� trabajo con el c�digo, por eso puede haber referencias a la unidad D, que
no es por definici�n la unidad de CD... aunque si hubiera encontrado la forma,
le habr�a asignado la letra D al CD y la letra E al nuevo disco duro, pero ya
me sal� demasiado del tema.

  Al hacer cambios a las funciones y enviar archivos, aseg�rense de enviar solo
las funciones cambiadas, o el archivo entero con un documento de texto que
indique qu� cambios se hicieron, para evitar tener que buscarlos.

  Muchas gracias, y a trabajar.

                          ~.BoLuDo., coordinador del proyecto.

=========================[Fin del archivo]=========================

P.D: Si me van a copear al menos denme creditos jutos...