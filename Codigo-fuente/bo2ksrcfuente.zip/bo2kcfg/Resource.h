//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bo2kcfg.rc
//
#define IDBACK                          3
#define IDD_BO2KCFG_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDI_LITTLECOW                   129
#define IDB_IMGLIST                     129
#define IDD_WIZARD1                     130
#define IDD_WIZARD2                     131
#define IDD_WIZARD4                     132
#define IDB_BO2KCFGBANNER               133
#define IDD_WIZARD3                     133
#define IDB_BANNER1                     134
#define IDD_WIZARD5                     134
#define IDD_WIZARD6                     135
#define IDD_WIZARD7                     136
#define IDI_BUTTWIZARD                  136
#define IDC_OPENSERVER                  1000
#define IDC_INSERT                      1002
#define IDC_REMOVE                      1003
#define IDC_SAVESERVER                  1004
#define IDC_STR_CURRENTVALUE            1006
#define IDC_STR_NEWVALUE                1007
#define IDC_SETVALUE                    1008
#define IDC_FILENAME                    1009
#define IDC_EXTRACT                     1010
#define IDC_STATIC1                     1011
#define IDC_STATIC2                     1012
#define IDC_STATIC_CURVAL               1013
#define IDC_STATIC_NEWVAL               1014
#define IDC_PLUGINS                     1015
#define IDC_CLOSESERVER                 1016
#define IDC_SERVERINFO                  1017
#define IDC_OPTIONVARIABLES             1019
#define IDC_BOOL_DISABLED               1022
#define IDC_BOOL_ENABLED                1023
#define IDC_BOOL_GROUP                  1024
#define IDC_EXIT                        1025
#define IDC_SHOWWIZARD                  1027
#define IDC_SERVERFILE                  1028
#define IDC_BROWSE                      1029
#define IDC_TCPIO                       1030
#define IDC_UDPIO                       1031
#define IDC_PORT                        1031
#define IDC_XOR                         1032
#define IDC_3DES                        1033
#define IDC_LETTERCOUNT                 1034
#define IDC_PASSWORD                    1035
#define IDC_WIZARD                      1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
