//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by C:\projects\bo2k\bo_peep\bo_peep.rc
//
#define IDI_BO_PEEP                     100
#define IDD_ADVDLG                      101
#define IDD_VIDSTREAMDLG                102
#define IDD_HIJACKDLG                   103
#define IDI_MOUSE                       111
#define IDI_REDMOUSE                    112
#define IDI_KEYBOARD                    113
#define IDC_INACTIVE                    114
#define IDC_REMOTEPOINTER               115
#define IDC_VIDSTREAM                   1000
#define IDC_COPY                        1003
#define IDC_HIJACK                      1004
#define IDC_OVERLAY                     1004
#define IDC_FRAME                       1005
#define IDC_CONNECT                     1006
#define IDC_HOTKEY                      1011
#define IDC_OWNMOUSE                    1012
#define IDC_OWNKEYBD                    1014
#define IDC_MOUSETIME                   1018
#define IDC_LOCK                        1020
#define IDC_MOUSETIMETEXT               1021
#define IDC_HOTKEYTEXT                  1022
#define IDC_KEY_AT                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
