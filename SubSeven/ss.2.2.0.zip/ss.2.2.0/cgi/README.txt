
 ** SUBSEVEN LOGGER V1.0 **
	please read this file before your run or upload any files to your serve.

 ** DOES YOUR SERVER SUPPORT CGI **
	You cant go any further if your server does not offer cgi access.  It is not
	hard however to get a free host that offers CGI access.  Here is a list of 
	sites that support CGI access and are free.

            SITE ADDRESS     |    GRADE     |  ADD BANNER REMOVAL
          ---------------------------------------------------------
	  www.virtualave.net | **** A+ **** |  Easy as hell
	  www.hypermart.net  | **** C+ **** |  Easy as hell
          www.vr9.com        | **** B- **** |  Some what easy


	if you know of anymore, please email black@black-fire.net.
	here is a list of free hosts that DO NOT support cgi access.

              SITE ADDRESS    |    GRADE     |  ADD BANNER REMOVAL
          ---------------------------------------------------------
	  www.angelfire.com   | **** A- **** |  SOME WHAT easy
	  www.freeservers.com | **** D- **** |  Imposible
          www.tripod.com      | **** B  **** |  Easy
          www.geocities.com   | **** B  **** |  Little difficult.


	if you know of anymore, please email black@black-fire.net

 ** LOCATION OF FILES **
	You must put all of the subseven log files in your cgi-bin.  If you don�t
	have a cgi bin, but you know your server supports cgi access, then you 
	most likely can put the files in any folder.  However to keep your site 
	clean, and organized you should make a cgi-bin and put all of your cgi 
	programs in it.

 ** REQUIRED RAW CHANGES **	

	Because your server may have several versions of PERL, you are required to
	put the correct path to PERL version 4 or 5 on the first line of every cgi
	file.  that would be every file that ends in ".cgi".  The location of PERL
	can usually be found by ether looking in your hosts FAQ for "CGI" or contacting
	your host and asking "Where is PERL located on your servers?".

	However most of the time the location of PERL is very similar to all servers.
	So try using the scripts on your server without editing them.  if you get a
	500 error or you see the source of the file, you need to change the location 
	of PERL.

	most servers use these paths to perl:
	/usr/bin/perl
	/usr/local/bin/perl

	I will accept requests to install this script on your server for you.  so if you
	have trouble, just ask.  however I will require your FTP server address and your 
	username and password (I can be trusted).

 ** CHMOD OF FILES ** 
	CHMOD is a permission setting of a file.  What this will do is make all the setting
	files private to you alone.  If you fail to CHMOD correctly, ether the program will
	not work or your passwords will be easy to recover by anyone on the net.

	The first thing you need to set the CHMOD of a file on your server, is to get an FTP
	program.  An FTP (file transfer protocol) program will allow you to upload, edit,
	delete, CHMOD, move, and other file manipulations.  A good and free FTP program is
	cuteFTP (made by global scape).  Because most user friendly FTP programs are very 
	similar to cuteFTP, that is what I will concentrate on.

	Read all steps before you perform them 
	  1) upload all files to a new folder in your CGI-BIN
	  2) DO NOT RENAME ANY OF THE FILES
	  3) in the window that shows the files you just uploaded (the server side) right click
		on the files.  A little menu will popup, asking you what you want to do to the  
		file.  one of the selections should be CHMOD.  select that option.
	  4) CHMOD the ".cgi" files to 755
	  5) CHMOD the rest of the files to 600 and if it dosnt work, you can chmod them to 777

 ** USING THE SETUP.CGI file **
	When you have finished uploading and CHMODing all the files, you can then install the
	script with your visual and security preferences.  

	Read all steps before you perform them 
	  1) open an internet browser
	  2) type in the path to the setup.cgi script you just uploaded.
	  3) fill in the requested information.
	  4) Click on the install button at the bottom of the program.
	  5) if you gave all the required information, the program will display security help.
	  6) read the help screen that opens.
	  7) do what the help screen asks (if you already have not)
	  8) read it then, as the script deletes its self after you run it.

	if you ever need to reinstall anything, you must re uploaded the "setup.cgi".
	and remember, you can change any of that information in the admin menu, after you 
	install the script.

 ** After you install **
	You should go to the subseven page (http://subseven.slak.org) to read how to setup the server
	so that it will record information with this script.
	
	and if you should ever get the message YOU ARE BANNED, that is a program added in that 
	prevents BRUTE FORCE.  you will get this message if you enter a wrong pass 10 times.  
	the bann only lasts 12-24 houres.  You must waite this time out, there is very little 
	you can do, other then using the correct login info.


 ** MORE HELP **
	A help screen can be found by typing 
	
	www.yoursite.com/cgi-bin/subseven.cgi?action=about

	from that location, you can page me or get my email, icq number, and web address.
	Questions will not be answered if they are answered in the http://subseven.slak.org FAQ and they
	most likely are, so check there first.  An updated version of this script will be
	found at www.black-fire.net and possibly www.sub7page.com
	


###################################################################
#                     +SUBSEVEN LOGGER+                           #
###################################################################
#                                                                 #
# SubSeven is provided 'as-is', without any express or implied    #
# warranty. in no event will the author be held liable for any    #
# damages arising from the use of it.                             #
#                                                                 #
# The author can't be held responsible for any illegal action(s)  #
# arising from the use of this software. Sub7 is provided for     #
# educational purposes only!                                      #
#                                                                 #
#                 SUBSEVEN CAN BE FOUND AT                        #
#                    http://subseven.slak.org                     #
#                                                                 #
###################################################################
