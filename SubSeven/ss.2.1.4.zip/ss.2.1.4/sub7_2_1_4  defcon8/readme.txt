[ SubSeven 2.1.4 DEF CON 8 readme file ]
 
check http://www.sub7.net for more info

special release for DEFCON8

mobman



Mirror http://www.hackpr.net
