
.S.u.b.S.e.v.e.n. .2.2. - http://www.sub7.net  Mirror http://www.hackpr.net

check the website for more documentation

===== editserver =====
the major difference is in editserver. everything is pretty
much self-explanatory, the features and eveything, but 
you'll notice there are no buttons to load the server from
a file or read settings from a server. that's because
everythign is based on a STUB [server.exe in the same folder
as editserver.exe]. whenever you start editserver, you're 
basically creating a new server.... all you have to do is 
set the settings and then save it to a file. this is for
security purposes and to ease up the configuration of a
server. i would _strongly_ recommend using the NORMAL
version of EditServer. loading presets from a file is not
yet implemented in teh normal version, only in advanced.

===== client =====
way too many changes to be listed here. just play around
with it, try to get used to all the new windows styles, 
the pages, commands. having the CONOLE always visible
is _strongly_ suggested. the menu is setup like the 2.1
menu, but it's highly configurable. actually, pretty much
everything is highly configurable.

don'y play around with the menu settings/pages/commands
if you don't know what you're doing. or, if you want to
try stuff out, make sure you backup the CFG files first.

===== plugins =====
if you're trying to use a feature that requires a plugin,
and that plugin is not installed on the server, the client
will automatically search the local plugins for that feature
and if found it will ask you if you want to upload the plugin
or not. you can disable this in preferences.

===== reporting bugs =====
remmeber, before reporting something, make sure you gather
as many details about the problem as possible. also
make sure you check the FAQ on the website.

that's it, i'm out.
have fun,
mobman
