ok.

run sub7, go to "local options" - "skins"

look at the bmp's to see how everything's working. it's REALLY easy.
if the skin doesn't have an INI file, default settings will be used.

one note:

the CONNECT and PING buttons on the main window are in the files:

con_btn.bmp
dis_btn.bmp
ping_btn.bmp

if these files are not included [like the WINDOWS skin] then default buttons
are used.


if you use a custom font for the buttons, add the TTF file to the skin folder.
subseven will automatically find it and install it.

mobman