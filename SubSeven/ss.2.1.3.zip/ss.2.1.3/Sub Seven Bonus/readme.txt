[ SubSeven 2.1.3 BONUS readme file ]
 
read disclaimer.txt before using.

check http://subseven.slak.org for more info

if you have any type of problems with the client, 
try double clicking the REG file included, it will
restore all settings to default.

try checking the HELP section before emailing
me or any of the crew members.

mobman

[7:09/6/2/2k]


www.sub7.net

Mirror http://www.hackpr.net


October, 2005
