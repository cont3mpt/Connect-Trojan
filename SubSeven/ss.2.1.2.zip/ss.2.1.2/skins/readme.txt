-
- SubSeven 2.1 M.U.I.E. skin readme.
-

* creating skins shouldn't be too hard considering the examples 
  included in the package.
* once you're done with the graphics, load the skin, and 
  go to "EDIT CURRENT SKIN" to set the colors.
* if you include a TTF file with your font, sub7 will 
  automatically install it.
* skins should be placed in a folder, and the folder in the SKINS folder.
  if you do this SubSeven will list the skin in the client.
* SKIN.INI is optional. if it's not included, default colors will be used.

the following files are optional:

con_btn.bmp
dis_btn.bmp
ping_btn.bmp

if they're not included, subseven will use the custom buttons.
see the FOREST skin to see how it's done.


mobman
[6:47/4/11/2k]